<?php

class FooClass2 extends BarClass2 { }
