<?php

class Foo2 {
	public function bar() {
		// }
		/*
		}
		*/
		$a = '}';
		$b = "}";
		return $a;
	}
}
