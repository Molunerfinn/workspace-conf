<?php
namespace NS2;

class NamespacedFoo {}
