<?php

class ChildFoo extends BaseFoo {
}

$f = new ChildFoo;
$f->inherited();
