<?php

/**
 * @return DateTime
 */
function dt() {
}

function baz() {
	$d = dt();
	$d->
}

class Foo {
    /**
     * @return DateTime
     */
    public function makeDateTime() {
		$d = dt();
		$d->
    }

    public function __construct() {
        $d = $this->makeDateTime();
        $d->
    }
}
