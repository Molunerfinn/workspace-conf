<?php

abstract class FooAbstract {
    public function foo() {
        $this->
        self::
    }
}
