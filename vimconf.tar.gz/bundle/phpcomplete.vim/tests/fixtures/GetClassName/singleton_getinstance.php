<?php

$foo = FooClass::getInstance();
$foo->

$foo2 = RenamedFoo::getInstance();
$foo2->

$foo3 = \NS2\Foo::getInstance();
$foo3->
