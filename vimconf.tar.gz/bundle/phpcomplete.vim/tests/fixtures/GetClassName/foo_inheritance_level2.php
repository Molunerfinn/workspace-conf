<?php
namespace NS2\SubNS;

use NS3\SubNS\Level3;

class Level2 extends Level3 {

	protected function level2Method_protected() {
		// 
	}


	public function level2Method_public() {
	}

}


?>

