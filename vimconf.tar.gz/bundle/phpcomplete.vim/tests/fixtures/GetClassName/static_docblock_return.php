<?php
class User {
    /**
     * @return User
     */
    public static function getUser(){ }
    public function find_me() { }
}
$u = User::getUser();
$u->
