<?php

trait Test1 {
}

	trait Test2
	{
	}

  trait Test3 {
  }
