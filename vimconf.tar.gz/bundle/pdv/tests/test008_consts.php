<?php

const FOO='bar';

class Bar {
	const BAR	=123;
}

  const BAZ = false;
